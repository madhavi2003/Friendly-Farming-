import secrets

# Generate a random secret key
secret_key = secrets.token_hex(24)  # You can adjust the length as needed
print(secret_key)

